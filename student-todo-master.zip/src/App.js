// import { Todo } from "./components/Todo";
import "./App.css";
// import "./components/todo.css"
import {Todo} from "./components/Todo"
function App() {
  
  return (
    <div >
      
      {/* <h1 className="title">Todo...</h1> */}
        <Todo/>
      
    </div>
  );
}

export default App;
