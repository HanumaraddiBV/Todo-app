import "../App.css";
import { useState, useEffect } from "react";

const axios = require("axios");
export const Todo = () => {
  const [Todo, setTodo] = useState([]);
  const [Text, setText] = useState("");
  const [Title, setTitle] = useState("");
  const [Page, setPage] = useState(1);
  useEffect(() => {
      getData();
    
    }, [Page]);
    // let c=0;
    // let totalPage = Math.ceil(c)
    // let x = document.querySelector(".prev").disabled = false;
    // if(Page == 1){
    //     x = document.querySelector(".prev").disabled = true;
    // } 
    const getData = async () => {
    return axios
      .get(
        `https://fake-api-project-for-masai.herokuapp.com/tasks?_page=${Page}&_limit=3`
      )
      .then((res) => {
          console.log('res:', res)
          let total = res.headers['X-Total-Count'];
          console.log('total:', total)
        setTodo(res.data);
      });
  };
 
  return (
    <div>
      <h1 className="title">Todo...</h1>
      <div>
        <input
          type="text"
          placeholder="Add title"
          className="inputTitle"
          onChange={(e) => setTitle(e.target.value)}
        ></input>
        <input
          type="text"
          placeholder="Add Task..."
          className="inputBody"
          onChange={(e) => setText(e.target.value)}
        ></input>
        <button
          className="addBtn"
          onClick={() => {
           
            axios
              .post("https://fake-api-project-for-masai.herokuapp.com/tasks", {
                title: Title,
                task: Text,
              })
              .then(getData);
          }}
        >
          Add
        </button>
      </div>
      {Todo.map((e) => {
        return (
          <div className="container" key={e.id}>
            {e.title} -{e.task} - {e.id}
          </div>
        );
      })}
      <div>
        <button
          className="prev"
          onClick={() => {
            setPage(Page - 1);
          }}
        >
          Prev
        </button>
        <button
          onClick={() => {
            console.log("hii");
            setPage(Page + 1);
          }}
        >
          Next
        </button>
      </div>
    </div>
  );
};
